#pragma once

#include "student.h"
#include <vector>
using namespace std;
void skaiciuoti_med_vid( Studentas &, const vector<unsigned> & );
