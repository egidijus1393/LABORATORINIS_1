#pragma once

#include "student.h"
#include <string>
#include <vector>
using namespace std;
void duomenys( string &, const string & );
void skaityti_is_failo( string &, const string & );
unsigned GautiSkaiciu( const string & );

void skaityti_is_failo( vector<Studentas> & );
void skaityti_is_ivesties( vector<Studentas> & );
void read_data( vector<Studentas> & );
