#pragma once

#include <string>
using namespace std;
struct Studentas {
    string vardas;
    string pavarde;
    unsigned egzamino_rez  = 0;
    double vidurkis      = 0;
    double mediana       = 0;
};
///aprasoma struktura.
