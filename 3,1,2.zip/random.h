#pragma once

#include <vector>
using namespace std;
void pazymiu_generavimas( vector<unsigned> &);
vector<unsigned> pazymiu_generavimas( unsigned );
///aprasoma pazymiu generavimo funkcija.
