#pragma once

#include "student.h"
#include <vector>
using namespace std;
void teksto_isvedimas( const vector<Studentas> & );
///aprasoma funkcija tekstui isvesti.
