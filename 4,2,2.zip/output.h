#pragma once

#include "student.h"
#include <iostream>
#include <vector>
using namespace std;
void rasyti_info( ostream &, const vector<Studentas> & );
///aprasoma funkcija tekstui isvesti.
